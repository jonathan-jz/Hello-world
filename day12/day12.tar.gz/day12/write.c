#include <func.h>
int main(){
    printf("write Hello!\n");
}