#include <func.h>
int main(){
    int x,y;
    scanf("%d%d",&x,&y);
    printf("read x + y = %d\n", x+y);
}