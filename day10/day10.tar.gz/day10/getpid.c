#include <func.h>
int main(){
    printf("pid = %d, ppid = %d\n",
        getpid(), getppid());
    return 0;
}