 ///
 /// @file    add.hpp
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-28 17:55:08
 ///
 

inline
int add(int x, int y)
{
	return x + y;
}
