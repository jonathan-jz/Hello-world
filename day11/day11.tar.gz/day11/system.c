#include <func.h>
int main(){
    //system("ls");
    system("python3 hello.py");
    sleep(5);
}