#include <func.h>
int main(){
    printf("I am sleep!\n");
    sleep(5);
}