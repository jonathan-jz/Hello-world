#include <func.h>
int main(){
    if(fork() == 0){
        return 0;
    }
    else{
        while(1){

        }
    }
}