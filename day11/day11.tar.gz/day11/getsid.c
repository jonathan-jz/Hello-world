#include <func.h>
int main(){
    printf("sid = %d\n", getsid(0));
}